package com.springboot.employee.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.springboot.employee.entity.Attendance;
import com.springboot.employee.entity.Department;
import com.springboot.employee.entity.Employee;
import com.springboot.employee.entity.Salary;
import com.springboot.employee.service.AttendanceService;
import com.springboot.employee.service.DepartmentService;
//import com.springboot.employee.service.AttendanceService;
//import com.springboot.employee.service.DepartmentService;
import com.springboot.employee.service.EmployeeService;
import com.springboot.employee.service.SalaryService;
//import com.springboot.employee.service.SalaryService;

@Controller
public class HomeController 
{
	
	private final EmployeeService empser;
	private final DepartmentService depser;
	private final SalaryService salser;
	private final AttendanceService attser;
	
	




	public HomeController(EmployeeService empser, DepartmentService depser, SalaryService salser,
			AttendanceService attser) {
		super();
		this.empser = empser;
		this.depser = depser;
		this.salser = salser;
		this.attser = attser;
	}








	

	@GetMapping("/")
    public String home() {
        return "home";
    }
	










	//Coding For employee entity has been started
	//1
	@GetMapping("/employee")
	public String showoperations()
	{
		return "operationsEmp";
	}
	//2
	@GetMapping("/GetEmployee")
	public String listEmployee(Model mod)
	{
		mod.addAttribute("employees",empser.getAllEmployee());
		return "employees";
	}
	
	//3
	@GetMapping("/Employee/New")
	public String CreateEmployee(Model mod)
	{
		Employee employee =new Employee();
		mod.addAttribute("employee", employee);
		return "create_employee";
		
	}
	
	//4
	
	
	@PostMapping("/Employee/save")
	public String saveEmployee(Employee employee, @RequestParam Long departmentId) {
	    
	    Department department = depser.getDepartmentById(departmentId);

	    // Make sure to set the Department for the Employee
	    employee.setDepartment(department);

	    // You may need additional logic here, e.g., validating input, handling errors, etc.
	    
	    empser.saveEmployee(employee);
	    return "redirect:/GetEmployee";
	}

	//5
	@GetMapping("/Employee/edit/{id}")
	public String editUserForm(@PathVariable int id , Model mod)
	{
		mod.addAttribute("employee", empser.getEmployeeById(id));
		return "edit_employee";
		
	}
	
	//6
	// Update data 
	@PostMapping("/employee/update/{id}")
	public String updateEmployee(@PathVariable long id , @ModelAttribute("employee") Employee employee , Model mod)
	{
		Employee existingEmployee = empser.getEmployeeById(id);
		existingEmployee.setEmployeeId(id);
		existingEmployee.setName(employee.getName());
		existingEmployee.setDateOfBirth(employee.getDateOfBirth());
		existingEmployee.setAddress(employee.getAddress());
		existingEmployee.setContactNumber(employee.getContactNumber());
		existingEmployee.setDesignation(employee.getDesignation());
		existingEmployee.setGender(employee.getGender());
		existingEmployee.setEmail(employee.getEmail());
		
		empser.saveEmployee(existingEmployee);
		return "redirect:/GetEmployee";
		
	}
	
	//7
	@GetMapping("/Employee/delete/{id}")
	public String deleteEmployee(@PathVariable int id )
	{
		empser.deleteEmployeeById(id);
		return "redirect:/GetEmployee";
		
	}
	
	
	//Employee coding ended
	
	
	//Coding For department entity has been started
	
	//1
	@GetMapping("/department")
	public String showoperations1()
	{
		return "operationsDep";
	}
	
	//2
		@GetMapping("/GetDepartment")
		public String listDepartment(Model mod)
		{
			mod.addAttribute("departments",depser.getAllDepartment());
			return "departments";
		}
		
		
		//3
		@GetMapping("/Department/New")
	    public String showDepartmentForm(Model model) {
	        model.addAttribute("department", new Department());
	        return "create_department";
	    }

		
		//4
	    @PostMapping("/Department/save")
	    public String saveDepartment(Department department) {
	        // You may need additional logic here, e.g., validating input, handling errors, etc.
	        depser.saveDepartment(department);
	        return "redirect:/GetDepartment";
	    }
	
	
	  //5
		@GetMapping("/Department/edit/{id}")
		public String editDepartmentForm(@PathVariable int id , Model mod)
		{
			mod.addAttribute("department", depser.getDepartmentById(id));
			return "edit_department";
			
		}
		
		//6
		// Update data 
		@PostMapping("/department/update/{id}")
		public String updateDepartment(@PathVariable long id , @ModelAttribute("department") Department department , Model mod)
		{
			Department exdep = depser.getDepartmentById(id);
			exdep.setDepartmentId(id);
			exdep.setDepartmentName(department.getDepartmentName());
			exdep.setLocation(department.getLocation());
			depser.saveDepartment(exdep);
			return "redirect:/GetDepartment";
			
		}
		
		//7
		@GetMapping("/Department/delete/{id}")
		public String deleteDepartment(@PathVariable int id )
		{
			depser.deleteDepartmentById(id);
			return "redirect:/GetDepartment";
			
		}
		
	
	//Department coding ended
	
	
	
	//Coding For salary entity has been started
	    //1
	@GetMapping("/salary")
	public String showoperations2()
	{
		return "operationsSal";
	}
	
	
	         //2
	
			@GetMapping("/GetSalary")
			public String listSalary(Model mod)
			{
				mod.addAttribute("salaries",salser.getAllSalary());
				return "salaries";
			}
	//3
			
			@GetMapping("/Salary/New")
		    public String showSalaryForm(Model model) {
		        model.addAttribute("salary", new Salary());
		        return "create_salary";
		    }
			
			
			//4
		    @PostMapping("/Salary/save")
		    public String saveSalary(Salary salary) {
		        // You may need additional logic here, e.g., validating input, handling errors, etc.
		        salser.saveSalary(salary);
		        return "redirect:/GetSalary";
		    }	
	
		    
		  //5
			@GetMapping("/Salary/edit/{id}")
			public String editSalaryForm(@PathVariable int id , Model mod)
			{
				mod.addAttribute("salary", salser.getSalaryById(id));
				return "edit_salary";
				
			}
			
			//6
			// Update data 
			@PostMapping("/salary/update/{id}")
			public String updateSalary(@PathVariable long id , @ModelAttribute("salary") Salary salary , Model mod)
			{
				Salary exsal = salser.getSalaryById(id);
				exsal.setSalaryId(id);
				exsal.setBasicSalary(salary.getBasicSalary());
				exsal.setBonus(salary.getBonus());
				exsal.setDeductions(salary.getDeductions());
				exsal.setNetSalary(salary.getNetSalary());
				exsal.setMonth(salary.getMonth());
				exsal.setYear(salary.getYear());
				salser.saveSalary(exsal);
				return "redirect:/GetSalary";
				
			}
			
			//7
			@GetMapping("/Salary/delete/{id}")
			public String deleteSalary(@PathVariable int id )
			{
				salser.deleteSalaryById(id);
				return "redirect:/GetSalary";
				
			}
			
	
	
	//Salary coding ended
	
	
	
	//Coding For attendance entity has been started
		    
    //1
	@GetMapping("/attendance")
	public String showoperations3()
	{
		return "operationsAtt";
		
	}
	
	
	
	//2
	
	@GetMapping("/GetAttendnace")
	public String listAttendance(Model mod)
	{
		mod.addAttribute("attendances",attser.getAllAttendance());
		return "attendances";
	}
//3
	
	@GetMapping("/Attendance/New")
    public String showAttendanceForm(Model model) {
        model.addAttribute("attendance", new Attendance());
        return "create_attendance";
    }
	
	
	//4
    @PostMapping("/Attendance/save")
    public String saveAttendance(Attendance attendance) {
        // You may need additional logic here, e.g., validating input, handling errors, etc.
        attser.saveAttendance(attendance);
        return "redirect:/GetAttendnace";
    }
	
    
    
	  //5
		@GetMapping("/Attendance/edit/{id}")
		public String editAttendanceForm(@PathVariable int id , Model mod)
		{
			mod.addAttribute("attendance", attser.getAttendanceById(id));
			return "edit_attendance";
			
		}
		
		//6
		// Update data 
		@PostMapping("/attendance/update/{id}")
		public String updateAttendance(@PathVariable long id , @ModelAttribute("attendance") Attendance attendance , Model mod)
		{
			Attendance exatt = attser.getAttendanceById(id);
			exatt.setAttendanceId(id);
			exatt.setDate(attendance.getDate());
			exatt.setInTime(attendance.getInTime());
			exatt.setOutTime(attendance.getOutTime());
			exatt.setStatus(attendance.getStatus());
			attser.saveAttendance(exatt);
			return "redirect:/GetAttendnace";
			
		}
		
		//7
		@GetMapping("/Attendance/delete/{id}")
		public String deleteAttendnace(@PathVariable int id )
		{
			attser.deleteAttendanceById(id);
			return "redirect:/GetAttendnace";
			
		}
		
	
	
	
	
	//Attendance coding ended
}
