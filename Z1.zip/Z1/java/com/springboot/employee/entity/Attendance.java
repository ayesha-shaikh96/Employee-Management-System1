package com.springboot.employee.entity;

import java.time.LocalDate;
import java.time.LocalTime;

import jakarta.persistence.*;

@Entity
@Table(name = "attendance")
public class Attendance {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long attendanceId;

    @ManyToOne
    @JoinColumn(name = "employee_id", nullable = false)
    private Employee employee;

    @Column(name="date", nullable = false)
    private LocalDate date;
    
    
    @Column(name="inTime", nullable = false)
    private LocalTime inTime;
    
    @Column(name="outTime", nullable = false)
    private LocalTime outTime;
    
    @Column(name="status", nullable = false)
    private String status; // e.g., Present, Absent, Late

    public Attendance() {

    }

    public Attendance(Long attendanceId, Employee employee, LocalDate date, LocalTime inTime, LocalTime outTime,
            String status) {
        super();
        this.attendanceId = attendanceId;
        this.employee = employee;
        this.date = date;
        this.inTime = inTime;
        this.outTime = outTime;
        this.status = status;
    }

    public Long getAttendanceId() {
        return attendanceId;
    }

    public void setAttendanceId(Long attendanceId) {
        this.attendanceId = attendanceId;
    }

    public Employee getEmployee() {
        return employee;
    }

    public void setEmployee(Employee employee) {
        this.employee = employee;
    }

    public LocalDate getDate() {
        return date;
    }

    public void setDate(LocalDate date) {
        this.date = date;
    }

    public LocalTime getInTime() {
        return inTime;
    }

    public void setInTime(LocalTime inTime) {
        this.inTime = inTime;
    }

    public LocalTime getOutTime() {
        return outTime;
    }

    public void setOutTime(LocalTime outTime) {
        this.outTime = outTime;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
