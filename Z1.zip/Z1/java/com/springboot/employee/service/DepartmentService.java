package com.springboot.employee.service;

import java.util.List;

import com.springboot.employee.entity.Department;



public interface DepartmentService
{
	
	
    List<Department> getAllDepartment();
	
    Department saveDepartment(Department department);
	
    Department getDepartmentById(long id);
	
	void deleteDepartmentById(long id);


}
