package com.springboot.employee.service;

import java.util.List;

import com.springboot.employee.entity.Employee;

public interface EmployeeService 
{
	
	
    List<Employee> getAllEmployee();
	
	Employee saveEmployee(Employee employee);
	
	Employee getEmployeeById(long id);
	
	void deleteEmployeeById(long id);
	
	

}
