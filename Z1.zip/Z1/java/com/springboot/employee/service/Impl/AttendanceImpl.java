package com.springboot.employee.service.Impl;


import java.util.List;

import org.springframework.stereotype.Service;

import com.springboot.employee.entity.Attendance;
import com.springboot.employee.repository.AttendanceRepository;
import com.springboot.employee.service.AttendanceService;

@Service
public class AttendanceImpl implements AttendanceService
{
	private AttendanceRepository attrepo;

	public AttendanceImpl(AttendanceRepository attrepo) {
		super();
		this.attrepo = attrepo;
	}

	@Override
	public List<Attendance> getAllAttendance() {
		
		return attrepo.findAll();
	}

	@Override
	public Attendance saveAttendance(Attendance attendance) {
		
		return attrepo.save(attendance);
	}

	@Override
	public Attendance getAttendanceById(long id) {
		
		return attrepo.findById(id).get();
	}

	@Override
	public void deleteAttendanceById(long id) {
		attrepo.deleteById(id);
		
	}
	
	
	

}
