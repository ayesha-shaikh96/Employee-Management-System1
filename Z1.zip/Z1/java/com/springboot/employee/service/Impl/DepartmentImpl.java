package com.springboot.employee.service.Impl;


import java.util.List;

import org.springframework.stereotype.Service;

import com.springboot.employee.entity.Department;
import com.springboot.employee.repository.DepartmentRepository;
import com.springboot.employee.service.DepartmentService;

@Service
public class DepartmentImpl implements DepartmentService
{

	private DepartmentRepository deprepo;
	
	
	
	public DepartmentImpl(DepartmentRepository deprepo) {
		super();
		this.deprepo = deprepo;
	}

	@Override
	public List<Department> getAllDepartment() {
		
		return deprepo.findAll();
	}

	@Override
	public Department saveDepartment(Department department) {
		
		return deprepo.save(department);
	}

	@Override
	public Department getDepartmentById(long id) {
		
		return deprepo.findById(id).get();
	}

	@Override
	public void deleteDepartmentById(long id)
	{
		deprepo.deleteById(id);
		
	}

}
