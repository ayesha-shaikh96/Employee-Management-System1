package com.springboot.employee.service.Impl;

import java.util.List;

import org.springframework.stereotype.Service;

import com.springboot.employee.entity.Salary;
import com.springboot.employee.repository.SalaryRepository;
import com.springboot.employee.service.SalaryService;

@Service
public class SalaryImpl implements SalaryService
{
	private SalaryRepository salrepo;

	
	
	
	public SalaryImpl(SalaryRepository salrepo) {
		super();
		this.salrepo = salrepo;
	}

	@Override
	public List<Salary> getAllSalary() {
		
		return salrepo.findAll();
	}

	
	@Override
	public void deleteSalaryById(long id) {
		salrepo.deleteById(id);
		
	}

	@Override
	public Salary saveSalary(Salary salary) {
		
		return salrepo.save(salary);
	}

	@Override
	public Salary getSalaryById(long id) {
		
		return salrepo.findById(id).get();
	}

}
